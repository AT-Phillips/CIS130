//document.write("<footer class='text-light bg-dark'>Thank you!</footer>");
document.getElementById ("theFooter").innterHTML = "<footer class='text-light bg-dark'>Thank you!</footer>";